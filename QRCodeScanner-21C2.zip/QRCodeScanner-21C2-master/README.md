# QR_Scanner-wida


# Berikut Hasil Pembuatan QR Code Scanner sebagai berikut melalui berbagai tahapan :



Screenshootnya =
=======================
a. Code Source:
- Main Activity
Dalam Main activity terdapat code source yang meliputi 4 Fungsi JSON, Call atau Telepon serta WEb View dan Map.
![image](https://user-images.githubusercontent.com/31887335/209883359-3995c21d-60e8-4b0f-852f-e95394bbcaf7.png)
![image](https://user-images.githubusercontent.com/31887335/209883474-ddd6d126-865e-4347-810c-c33715196d71.png)
![image](https://user-images.githubusercontent.com/31887335/209883509-ad10fbf3-094e-45ef-812a-5c74dc58d1d1.png)

b. Hasil Running App dan Commit & Push ke Github :
![image](https://user-images.githubusercontent.com/31887335/209882922-95b3111c-0e99-4f00-9289-7f732ddb1707.png)
![image](https://user-images.githubusercontent.com/31887335/209883089-8e79e7c4-5e50-4d25-a049-30490f3bb132.png)

![image](https://user-images.githubusercontent.com/31887335/209883071-94b2710c-0e36-4520-8436-69c231264cac.png)
